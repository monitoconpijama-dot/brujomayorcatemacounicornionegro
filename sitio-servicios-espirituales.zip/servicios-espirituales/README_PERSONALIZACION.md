# Guía de Personalización - Sitio Web de Servicios Espirituales

## 📋 Resumen del Proyecto

Este sitio web ha sido adaptado de la plantilla Plato de BootstrapMade para servicios espirituales. Incluye todas las secciones necesarias según los requerimientos: presentación personal, servicios, testimonios, preguntas frecuentes y contacto directo por WhatsApp.

## 🎯 Características Implementadas

### ✅ Secciones Incluidas
- **Hero/Inicio**: Mensaje principal con llamado a la acción de WhatsApp
- **Sobre Mí**: Historia personal y credenciales
- **Por Qué Elegirnos**: 6 razones clave para generar confianza
- **Llamado a la Acción**: CTA intermedio para conversión
- **Servicios**: 6 servicios principales con botones de WhatsApp
- **Testimonios**: 5 testimonios con sistema de carrusel
- **Preguntas Frecuentes**: 6 preguntas comunes con respuestas
- **Contacto**: WhatsApp, email y formulario de contacto
- **Footer**: Información completa y enlaces

### ✅ Elementos Técnicos
- Diseño responsivo (móvil, tablet, escritorio)
- Botón flotante de WhatsApp
- Animaciones on-scroll con AOS
- SEO básico implementado
- Meta tags optimizados
- Estructura HTML semántica
- Bootstrap 5.3.8

## 🔧 Personalización Necesaria

### 1. Número de WhatsApp
**IMPORTANTE**: Debes reemplazar `1234567890` con tu número real de WhatsApp en TODOS los enlaces.

Buscar y reemplazar en `index.html`:
```
wa.me/1234567890
```
Por:
```
wa.me/TU_NUMERO_CON_CODIGO_PAIS
```

Ejemplo para México: `wa.me/5215551234567` (52 es código de México)

### 2. Nombre/Marca del Sitio
Buscar y reemplazar `✨ Luz Espiritual` por tu nombre o marca personal.

### 3. Email de Contacto
Reemplazar `contacto@luzespiritual.com` por tu email real.

### 4. Imágenes

Las imágenes actuales son de la plantilla original. Debes reemplazarlas con imágenes apropiadas:

**Ubicación de imágenes**: `assets/img/`

| Archivo | Descripción | Tamaño Recomendado |
|---------|-------------|-------------------|
| `hero-bg.jpg` | Fondo de la sección principal | 1920x1080px |
| `about.jpg` | Imagen "Sobre Mí" principal | 800x600px |
| `about-2.jpg` | Imagen "Sobre Mí" secundaria | 800x600px |
| `cta-bg.jpg` | Fondo del llamado a la acción | 1920x1080px |
| `testimonials-bg.jpg` | Fondo de testimonios | 1920x1080px |
| `testimonials/testimonials-1.jpg` a `testimonials-5.jpg` | Fotos de testimonios | 100x100px (circular) |
| `favicon.png` | Ícono del navegador | 32x32px |
| `apple-touch-icon.png` | Ícono para iOS | 180x180px |

**Recomendaciones de imágenes**:
- Velas, cristales, elementos místicos
- Colores: morado, dorado, azul oscuro, tonos tierra
- Evitar imágenes genéricas de stock
- Optimizar para web (comprimir sin perder calidad)

### 5. Contenido Personalizado

#### Sección "Sobre Mí"
Editar el texto en la sección `#about` con tu historia real:
- Tu experiencia personal
- Cómo descubriste tus habilidades
- Tu filosofía de trabajo
- Valores y ética

#### Testimonios
Reemplazar los testimonios de ejemplo con casos reales (o realistas):
- Usar seudónimos si es necesario
- Incluir ciudad
- Mantener testimonios breves y específicos
- Agregar estrellas de calificación

#### Preguntas Frecuentes
Adaptar las preguntas según las dudas reales de tus clientes.

### 6. Colores y Estilo

Para cambiar los colores del sitio, editar el archivo `assets/css/main.css`:

Buscar las variables CSS principales y ajustar según tu paleta:
- Color primario (botones, enlaces)
- Color de fondo
- Color de texto
- Colores de secciones

### 7. Formulario de Contacto

El formulario usa `forms/contact.php`. Para que funcione necesitas:

1. Configurar el archivo `forms/contact.php` con tu email
2. O usar un servicio de formularios como:
   - Formspree
   - EmailJS
   - Web3Forms

Alternativamente, puedes eliminar el formulario y dejar solo WhatsApp.

## 📱 Integración de WhatsApp

### Botón Flotante
Ya implementado en la esquina inferior derecha. Siempre visible para facilitar contacto.

### Mensajes Predefinidos
Los enlaces de WhatsApp incluyen mensajes predefinidos:
- "Hola, me interesa una consulta espiritual"
- "Me interesa el servicio de amarres de amor"
- "Necesito una limpieza espiritual"
- etc.

Puedes personalizar estos mensajes en cada enlace.

## 🚀 Cómo Probar el Sitio

### Opción 1: Abrir directamente
Abre `index.html` en tu navegador web.

### Opción 2: Servidor local (recomendado)
```bash
cd /home/ubuntu/servicios-espirituales
python3 -m http.server 8000
```
Luego abre: `http://localhost:8000`

## 📦 Estructura de Archivos

```
servicios-espirituales/
├── index.html                 # Página principal (YA ADAPTADA)
├── assets/
│   ├── css/
│   │   └── main.css          # Estilos principales
│   ├── img/                  # Imágenes (REEMPLAZAR)
│   ├── js/
│   │   └── main.js           # JavaScript principal
│   └── vendor/               # Librerías (Bootstrap, etc.)
├── forms/
│   └── contact.php           # Script de formulario (CONFIGURAR)
└── README_PERSONALIZACION.md # Esta guía
```

## 🎨 Sugerencias de Diseño

### Paleta de Colores Espirituales
- **Morado**: #6B46C1 (espiritualidad, intuición)
- **Dorado**: #D4AF37 (abundancia, sabiduría)
- **Azul Oscuro**: #1E3A8A (confianza, profundidad)
- **Verde Esmeralda**: #047857 (sanación, equilibrio)
- **Blanco/Crema**: #F9FAFB (pureza, claridad)

### Tipografía
- Títulos: Elegantes pero legibles
- Texto: Claro y profesional
- Evitar fuentes muy decorativas que dificulten la lectura

## 🔍 SEO Básico Implementado

Ya incluido en el sitio:
- Meta description optimizada
- Keywords relevantes
- Estructura HTML semántica (H1, H2, H3)
- Alt text en imágenes (agregar al reemplazar imágenes)
- URLs limpias
- Responsive design

### Para Mejorar SEO:
1. Agregar más contenido original
2. Incluir blog con artículos (opcional)
3. Optimizar velocidad de carga
4. Configurar Google Analytics
5. Crear cuenta de Google My Business (si ofreces atención presencial)

## 📊 Optimización de Rendimiento

### Imágenes
- Comprimir todas las imágenes antes de subirlas
- Usar formatos modernos: WebP
- Implementar lazy loading (ya incluido)

### Hosting
Recomendaciones para hospedar el sitio:
- **Netlify** (gratis, fácil, HTTPS automático)
- **Vercel** (gratis, rápido)
- **GitHub Pages** (gratis)
- **Hostinger** (económico, soporte en español)

## 🔒 Seguridad y Privacidad

### Aviso de Privacidad
Debes crear una página `privacy.html` con tu aviso de privacidad que incluya:
- Qué datos recopilas
- Cómo los usas
- Cómo los proteges
- Derechos del usuario

### HTTPS
Asegúrate de que tu sitio use HTTPS (certificado SSL). La mayoría de hostings modernos lo incluyen gratis.

## 📞 Próximos Pasos

1. ✅ Reemplazar número de WhatsApp
2. ✅ Cambiar nombre/marca
3. ✅ Actualizar email
4. ✅ Reemplazar todas las imágenes
5. ✅ Personalizar contenido "Sobre Mí"
6. ✅ Agregar testimonios reales
7. ✅ Ajustar colores (opcional)
8. ✅ Configurar formulario de contacto
9. ✅ Crear aviso de privacidad
10. ✅ Probar en diferentes dispositivos
11. ✅ Subir a hosting
12. ✅ Configurar dominio personalizado (opcional)

## 💡 Consejos Finales

### Contenido
- Sé honesto y transparente
- Usa un tono cercano pero profesional
- Enfatiza beneficios, no solo características
- Incluye llamados a la acción claros

### Conversión
- Facilita el contacto (WhatsApp siempre visible)
- Ofrece consulta gratuita para reducir fricción
- Genera confianza con testimonios y experiencia
- Responde rápido a los mensajes

### Mantenimiento
- Actualiza testimonios regularmente
- Agrega nuevos servicios si aplica
- Mantén el contenido fresco
- Responde a todos los mensajes de contacto

## 🆘 Soporte

Si necesitas ayuda adicional:
- Revisa la documentación de Bootstrap: https://getbootstrap.com
- Consulta tutoriales de HTML/CSS básico
- Considera contratar un desarrollador web para personalizaciones avanzadas

---

**¡Éxito con tu sitio web de servicios espirituales!** 🌟
